<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class categorias extends Model
{
   protected $table ='tb_categoria';
}
