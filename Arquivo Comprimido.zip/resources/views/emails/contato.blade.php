<div class="panel panel-default">
    <div class="panel-heading"><label class="label label-success">{{$nome}} - {{$email}}</label></div>
    <div class="panel-body">
    	<h4>Telefone: {{$phone}}</h4>
        <p>
        {{$mensagem}}
        </p>
    </div>

</div>