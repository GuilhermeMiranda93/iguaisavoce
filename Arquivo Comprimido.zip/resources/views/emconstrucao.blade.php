<html>
	<head>
		<style>
			img{
				width: 80%;
			}
			body{
				display: flex;
				align-items: center;
				justify-content: center;
			}
		</style>
	</head>
	<body>
		<img src="construcao.png">
	</body>
</html>